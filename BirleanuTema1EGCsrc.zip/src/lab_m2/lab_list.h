#pragma once

#include "lab_m2/lab1/lab1.h"
#include "lab_m2/lab2/lab2.h"
#include "lab_m2/lab3/lab3.h"
#include "lab_m2/lab4/lab4.h"
#include "lab_m2/lab5/lab5.h"
#include "lab_m2/lab6/lab6.h"
#include "lab_m2/lab7/lab7.h"
#include "lab_m2/lab8/lab8.h"
